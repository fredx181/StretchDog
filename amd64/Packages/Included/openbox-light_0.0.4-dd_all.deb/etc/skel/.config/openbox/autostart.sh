#!/bin/sh
#xdotool key ctrl+alt+space &
chpupsocket $USER:$USER &

#netmon_wce &
#wicd-gtk --tray &

# Bottom panel
tint2 &



parcellite &
sleep 1
frisbee-tray &

if [ -f /mnt/live/tmp/modules ]; then
conky -c ~/.conkyrc-port &
else
conky -c ~/.conkyrc-live &
fi
wait $!
#wbar &
volumeicon &
sleep 2

#desktop_drive_icons &
# Provides the desktop of choice, e.g. tint2 left icon panel or rox pinboard
# Can be selected from Menu > Desktop Manager
. $HOME/.config/openbox/set-desktop &
#wbar &
# Pre-load menu
xdotool key ctrl+alt+space
openbox --reconfigure
#sleep 5
#wbar &

