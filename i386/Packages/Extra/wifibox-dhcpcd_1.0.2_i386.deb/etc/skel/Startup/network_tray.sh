#!/bin/sh
[ -z "`pidof network_tray`" ] && network_tray &
