#!/bin/sh

kill $(ps ax | grep gtkdialog | grep WEBSEARCHGUI | awk '{print $1}' );
exec websearch &
