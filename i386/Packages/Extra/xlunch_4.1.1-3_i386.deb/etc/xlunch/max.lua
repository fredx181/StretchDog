if (get_application_name()=="xlunch: Graphical app launcher") then
	maximize();
end