#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <gtk/gtk.h>
/*---------------------------------------------------------------------------*/
/* global variables */
GtkWidget *combo1, *combo2;
gchar *dirselect;
char comstring[256];

/* GTK callback functions for Buttons in window1 */

static gboolean delete_event(GtkWidget * widget, GdkEvent * event, gpointer data)
{
  g_print("Delete event occurred\n");

  return FALSE;
}
 
static void destroy(GtkWidget * widget, gpointer data)
{
  g_print("Destroy signal was sent\n");
  gtk_main_quit();
}
/*---------------------------------------------------------------------------*/

/* call GTK widget-dialog file_chooser_dialog for file_save */
void on_button1_clicked (GtkWidget* widget, gpointer data)
{
	GtkWidget * dir_save;  // file_chooser_dialog
	dir_save = gtk_file_chooser_dialog_new("select DIR for save", NULL,
								GTK_FILE_CHOOSER_ACTION_SELECT_FOLDER,
            					GTK_STOCK_CANCEL, 
								GTK_RESPONSE_CANCEL, 
								GTK_STOCK_SAVE, 
								GTK_RESPONSE_ACCEPT, NULL);
	if (gtk_dialog_run(GTK_DIALOG (dir_save)) == GTK_RESPONSE_ACCEPT)
	{
		dirselect = gtk_file_chooser_get_current_folder (GTK_FILE_CHOOSER (dir_save));
		/* see #include <unistd.h> */
		chdir (dirselect);
		//printf("Selected path=%s\n", dirselect); // for Debug only!
	}
	gtk_widget_destroy (dir_save);
}

/* make command string for execute scrot */
void on_button2_clicked (GtkWidget* widget, gpointer data)
{
	gint cbo1;
	char *cbo2;
	cbo1 = gtk_combo_box_get_active (combo1); // get selected as Integer
    cbo2 = gtk_combo_box_get_active_text (combo2); // get selected as TEXT
	/* Full command string may be: scrot -s -b -d 2 -e 'mv $f ~/' */
	/* Selected in Combo1: "All"=0=-m "window"=1=-u "area"=2=-s */
	/* !!! Attention: key "-u" works in scrot ver. >= 0.8 only !!! */
	if (cbo1==0)
    	sprintf(comstring, "scrot -m -b -d %s", cbo2);
	if (cbo1==1)
    	sprintf(comstring, "scrot -u -b -d %s", cbo2);
	if (cbo1==2)
		sprintf(comstring, "scrot -s -b -d %s", cbo2);
	//printf("Command string: %s\n", comstring); // for Debug only!
	system (comstring);
}
/*---------------------------------------------------------------------------*/

int main(int argc, char ** argv)
{
    gtk_init (&argc, &argv);

    GtkWidget *window1;
    GtkWidget *box1, *box2, *box3, *box4, *box5;
    GtkWidget *button1, *button2, *button3;
    GtkWidget *label1, *label2;
	// GtkWidget *combo1, *combo2; moved to global

    const gchar *title = "SCReen-shOT";
    gchar *combotext1[] = {"All", "window", "area"};
    gchar *combotext2[] = {"0", "1", "2", "3", "5", "10", "20", "30"};

    /* Standard window-creating stuff */
    window1 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
    gtk_window_set_position (GTK_WINDOW(window1), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_window_set_title (GTK_WINDOW (window1), title);
    gtk_widget_set_usize(window1, 220, 90);

    button1 = gtk_button_new_with_label("Save as");
    button2 = gtk_button_new_with_label("EXECUTE");
	button3 = gtk_button_new_with_label("Quit");
    label1 = gtk_label_new("Grab-mode");
    label2 = gtk_label_new("Time-delay");

    /* insert comboboxes into window1 */
    combo1 = gtk_combo_box_new_text();
	gtk_combo_box_append_text (GTK_COMBO_BOX (combo1), combotext1[0]);
	gtk_combo_box_append_text (GTK_COMBO_BOX (combo1), combotext1[1]);
	gtk_combo_box_append_text (GTK_COMBO_BOX (combo1), combotext1[2]);
	gtk_combo_box_set_active (combo1, 1);
    combo2 = gtk_combo_box_new_text();
	gtk_combo_box_append_text (GTK_COMBO_BOX (combo2), combotext2[0]);
	gtk_combo_box_append_text (GTK_COMBO_BOX (combo2), combotext2[1]);
	gtk_combo_box_append_text (GTK_COMBO_BOX (combo2), combotext2[2]);
	gtk_combo_box_append_text (GTK_COMBO_BOX (combo2), combotext2[3]);
	gtk_combo_box_append_text (GTK_COMBO_BOX (combo2), combotext2[4]);
	gtk_combo_box_append_text (GTK_COMBO_BOX (combo2), combotext2[5]);
	gtk_combo_box_append_text (GTK_COMBO_BOX (combo2), combotext2[6]);
	gtk_combo_box_append_text (GTK_COMBO_BOX (combo2), combotext2[7]);
	gtk_combo_box_set_active (combo2, 2);

    box1 = gtk_vbox_new (FALSE, 3);  // frame vertcal-box
    gtk_container_add (GTK_CONTAINER (window1), box1);
    gtk_widget_show (box1);

    box2 = gtk_hbox_new (FALSE, 3);  // frame horiz-box
    gtk_container_set_border_width (GTK_CONTAINER (box2), 1);
    gtk_box_pack_start (GTK_BOX (box1), box2, TRUE, TRUE, 0);
    gtk_widget_show (box2);

    box3 = gtk_hbox_new (FALSE, 3);  // frame horiz-box
    gtk_container_set_border_width (GTK_CONTAINER (box3), 1);
    gtk_box_pack_start (GTK_BOX (box1), box3, TRUE, TRUE, 0);
    gtk_widget_show (box3);

    box4 = gtk_vbox_new (FALSE, 3);  // frame vertcal-box
    gtk_container_set_border_width (GTK_CONTAINER (box4), 1);
    gtk_box_pack_start (GTK_BOX (box2), box4, TRUE, TRUE, 0);
    gtk_widget_show (box4);

    box5 = gtk_vbox_new (FALSE, 3);  // frame vertcal-box
    gtk_container_set_border_width (GTK_CONTAINER (box5), 1);
    gtk_box_pack_start (GTK_BOX (box2), box5, TRUE, TRUE, 0);
    gtk_widget_show (box5);

    /* Standard window-destroy stuff */
    g_signal_connect(G_OBJECT(window1), "delete_event", G_CALLBACK(delete_event), NULL);
    g_signal_connect (window1, "destroy", G_CALLBACK (gtk_main_quit), NULL);
    /* by pressing button3 Quit on window1 */
    g_signal_connect_swapped (button3, "clicked", G_CALLBACK (gtk_main_quit), NULL);
    /* by pressing button1 Save as on window1 */
    /* callback-func. button1_clicked swap parameter with func. on_button1_clicked */
    g_signal_connect_swapped(G_OBJECT(button1), "clicked", G_CALLBACK(on_button1_clicked), G_OBJECT(window1));
    /* by pressing button2 EXECUTE on window1 */
    /* callback-func. button1_clicked swap parameter with func. on_button2_clicked */
    g_signal_connect_swapped(G_OBJECT(button2), "clicked", G_CALLBACK(on_button2_clicked), G_OBJECT(window1));

	/* set all widgets into boxes */
    gtk_container_add (GTK_CONTAINER (box3), button1);
    gtk_container_add (GTK_CONTAINER (box3), button2);
	gtk_container_add (GTK_CONTAINER (box3), button3);
	gtk_container_add (GTK_CONTAINER (box4), label1);
    gtk_container_add (GTK_CONTAINER (box4), combo1);
	gtk_container_add (GTK_CONTAINER (box5), label2);
    gtk_container_add (GTK_CONTAINER (box5), combo2);

  gtk_widget_show_all (window1);
  gtk_main();
  return 0;
}

