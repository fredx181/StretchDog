#!/bin/sh

[ ! -f /usr/local/bin/unzipper ] && echo Unzipper not installed! && exit

SOURCE=$(ls *.gz 2>/dev/null)
[ -z "$SOURCE" ] && echo OpenOffice source package not found! && exit

LANGCODE=${SOURCE##*_}
LANGCODE=${LANGCODE%.tar.gz}
[ -z "$LANGCODE" ] && echo Language code not identified! && exit
SQUASH=${SOURCE%install-deb_*}${LANGCODE}.squashfs

rm -rf /tmp/$LANGCODE

echo In the next step, Unzipper will run.
echo  You will extract the OpenOffice source into /tmp
read -p "Press Enter to start: "

unzipper $SOURCE

dpkg -i /tmp/$LANGCODE/DEBS/*.deb  #into /opt/openoffice4
mkdir -p /opt/build/opt
mv /opt/openoffice4 /opt/build/opt
mksquashfs /opt/build $SQUASH
rm -rf /opt/build

cp /tmp/en-GB/DEBS/desktop-integration/*.deb .	#this is the menu setup file

echo Done!
