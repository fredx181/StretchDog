#!/bin/sh

[ ! -f /usr/local/bin/unzipper ] && echo Unzipper not installed! && exit

SOURCE=$(ls *.gz 2>/dev/null)
[ -z "$SOURCE" ] && echo LibreOffice source package not found! && exit

echo In the next step, Unzipper will run.
echo  You will extract the LibreOffice source into /tmp
read -p "Press Enter to start: "

unzipper $SOURCE

LIBRE=$(ls -1 /tmp | grep Libre)
[ -z "$LIBRE" ] && echo LibreOffice extraction failed! && exit
SQUASH=${LIBRE}.squashfs

mv /tmp/$LIBRE/DEBS/*menus*.deb .	#this is the menu setup file

dpkg -i /tmp/$LIBRE/DEBS/*.deb  #into /opt/libreoffice4
mkdir -p /opt/build/opt

mv /opt/libreoffice* /opt/build/opt
mksquashfs /opt/build $SQUASH
rm -rf /opt/build

rm -rf /tmp/$LIBRE
echo Done!
